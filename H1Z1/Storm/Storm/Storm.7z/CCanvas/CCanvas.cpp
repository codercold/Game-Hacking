#include "stdafx.h"

CDX9Canvas Canvas;
CCanvas* pCanvas;